package com.example.tooth_lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
